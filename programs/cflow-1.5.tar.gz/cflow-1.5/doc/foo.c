/* foo.c */
int
main()
{
    f();
    g();
    f();
}

int
f()
{
    i = h();
}
