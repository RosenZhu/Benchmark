
int main(){
	int a,b;
	a=1;
	b=a+2;
}
